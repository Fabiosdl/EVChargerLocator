import React, { Component } from "react";
import { locationsArray } from "./locations";
import { GoogleMap, LoadScript, Marker, DirectionsRenderer } from "@react-google-maps/api";
import "./styles.css";
import background from "./images/background_2.webp";
import { getDistance } from "geolib";
class App extends Component {
  // our App constructor - with some state variables.

  constructor(props) {
    super(props);
    this.state = {
      globalArray: locationsArray,
      distance: 0,
      myChoice: null,
      myChoice1: null,
      ChargerChoice: null,
      directions: null,
      //dropdown values for the 3 standard charging types
      Charger: [
        { id: 1, charger: "CHAdeMO" },
        { id: 2, charger: "Type 2" },
        { id: 3, charger: "CCS/SAE" }
      ],
      //dropdown choices for 26 counties in rep.of Ireland
      counties: [
        { id: 1, county: "Carlow" },
        { id: 2, county: "Cavan" },
        { id: 3, county: "Clare" },
        { id: 4, county: "Cork" },
        { id: 5, county: "Donegal" },
        { id: 6, county: "Dublin" },
        { id: 7, county: "Galway" },
        { id: 8, county: "Kerry" },
        { id: 9, county: "Kildare" },
        { id: 10, county: "Kilkenny" },
        { id: 11, county: "Laois" },
        { id: 12, county: "Leitrim" },
        { id: 13, county: "Limerick" },
        { id: 14, county: "Longford" },
        { id: 15, county: "Louth" },
        { id: 16, county: "Mayo" },
        { id: 17, county: "Meath" },
        { id: 18, county: "Offaly" },
        { id: 19, county: "Roscomon" },
        { id: 20, county: "Sligo" },
        { id: 21, county: "Tipperary" },
        { id: 22, county: "Waterford" },
        { id: 23, county: "Westmeath" },
        { id: 24, county: "Wexford" },
        { id: 25, county: "Wicklow" }
      ],

        mapApiKey: "AIzaSyBxVc8s7hrdb9oetf2-rkivQJa2-qnfhmQ", // Replace with your actual API key
        mapCenter: { lat: 0, lng: 0 }, // Default map center
        showMap: false, // Toggle to show/hide the map

    };
    //bind the dropdown fields to their respective event handlers
    this.handleListChange = this.handleListChange.bind(this);
    this.handleListPlacename = this.handleListPlacename.bind(this);
    this.handleListChargertype = this.handleListChargertype.bind(this);
    this.calculate = this.calculate.bind(this);
  }
  // Event handlers for the drop-down-lists

  handleListChange(event) {
    this.setState({ myChoice: event.target.value });
  }

  handleListPlacename(event) {
    this.setState({ myChoice1: event.target.value });
  }

  handleListChargertype(event) {
    this.setState({ ChargerChoice: event.target.value });
  }

  //filters for each respective dropdown field
  filterChoice(input) {
    return function (arrayObject) {
      return input === arrayObject.county;
    };
  }
  filterPlacename(input) {
    return function (arrayObject_1) {
      return input === arrayObject_1.placename;
    };
  }
  filterChargertype(input) {
    return function (arrayObject_2) {
      return arrayObject_2.charger.includes(input);
    };
  }

  //sort methods to list dropdown options in alphabetical order
  sortCounties(dx, dy) {
    let DX = dx.id;
    let DY = dy.id;
    if (DX > DY) return 1;
    else if (DX < DY) return -1;
    else return 0;
  }
  sortPlacenames(px, py) {
    let PX = px.placename.toUpperCase();
    let PY = py.placename.toUpperCase();
    if (PX > PY) return 1;
    else if (PX < PY) return -1;
    else return 0;
  }
  sortChargertype(cx, cy) {
    let CX = cx.id;
    let CY = cy.id;
    if (CX > CY) return 1;
    else if (CX < CY) return -1;
    else return 0;
  }

  //functions to calculate user's distance from current location to the selected charge point
  async calculate() {
    let lat;
    let long;

    //use the functions from geolib to find current location
    if (navigator.geolocation) {
      const getPosition = () => {
        return new Promise((res, rej) => {
          navigator.geolocation.getCurrentPosition(res, rej);
        });
      };
      const x = await getPosition();

      lat = x.coords.latitude;
      long = x.coords.longitude;
    } else {
      //in case user has blocked location tracking or brower is incapable
      console.log("Geolocation is not supported by this browser.");
    }

    const array = this.state.globalArray
        .filter(this.filterChargertype(this.state.ChargerChoice))
        .filter(this.filterChoice(this.state.myChoice))
        .filter(this.filterPlacename(this.state.myChoice1));

    //use function from geolib to calculate difference between current location and the lat/long of the selected charge point
    const dis = getDistance(
        { latitude: lat, longitude: long },
        {
          latitude: array[0].latitude,
          longitude: array[0].longitude
        }

    );

    //pass the calculated distance back to the parent via setState
    this.setState({
      mapCenter: {
        markers: [{ lat, lng: long }],
        lat: array[0].latitude,
        lng: array[0].longitude,
      },
      showMap: true, // Show the map
    });
  };

  openGoogleMaps = async () => {
    const { mapCenter, myChoice, myChoice1 } = this.state;

    // Fetch user's current location
    let userLocation = null;
    if (navigator.geolocation) {
      try {
        const position = await new Promise((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject);
        });

        userLocation = position.coords;
      } catch (error) {
        console.error("Error getting user's current location:", error);
      }
    } else {
      console.log("Geolocation is not supported by this browser.");
    }

    // Use user's current location in the URL
    const origin = userLocation
        ? `${userLocation.latitude},${userLocation.longitude}`
        : `${mapCenter.lat},${mapCenter.lng}`;

    const destination = `${myChoice1}, ${myChoice}, Ireland`;
    const url = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}`;
    window.open(url, "_blank");
  };
  displayDirections = () => {
    const { mapCenter, myChoice, myChoice1 } = this.state;

    if (!mapCenter.lat || !mapCenter.lng || !myChoice1) {
      console.error("Invalid data to calculate directions");
      return;
    }

    const directionsService = new window.google.maps.DirectionsService();

    directionsService.route(
        {
          origin: { lat: mapCenter.lat, lng: mapCenter.lng },
          destination: `${myChoice1}, ${myChoice}, Ireland`,
          travelMode: window.google.maps.TravelMode.DRIVING,
        },
        (response, status) => {
          if (status === window.google.maps.DirectionsStatus.OK) {
            this.setState({
              directions: response,
            });
          } else {
            console.error("Error fetching directions:", status);
          }
        }
    );
  };


  render() {
    return (
        <div
            className="App"
            //some aesthetic styling
            style={{
              backgroundImage: "url(" + background + ")",
              backgroundPosition: "center",
              backgroundSize: "cover",
              backgroundRepeat: "no-repeat"
            }}
        >
          {/*main page content begins*/}
          <h1>Electric Vehicle Chargers Locator</h1>
          <h2>
            <b>EV Charge Points</b>
          </h2>

          <form>
            <b>Choose Desired Charger Type: </b>

            {/* dropdown choices will trigger their respective event handler above */}
            <select onChange={this.handleListChargertype}>
              <option>Select</option>
              {this.state.Charger.sort(this.sortChargertype).map((s, key) => (
                  <option key={key} value={s.charger}>
                    {s.charger}
                  </option>
              ))}
            </select>

            {this.state.ChargerChoice && (
                <blockquote>
                  Selected Charger Type: <b>{this.state.ChargerChoice}</b>
                </blockquote>
            )}

            <hr />
            <b>Choose Desired County: </b>
            <select onChange={this.handleListChange}>
              <option>Select</option>
              {this.state.counties.sort(this.sortCounties).map((s, key) => (
                  <option key={key} value={s.county}>
                    {s.county}
                  </option>
              ))}
            </select>
            {this.state.myChoice && (
                <blockquote>
                  Selected County: <b>{this.state.myChoice}</b>
                </blockquote>
            )}
            <hr />
            <b>Choose Desired Place Name: </b>
            <select onChange={this.handleListPlacename}>
              <option>Select</option>
              {this.state.globalArray
                  .filter(this.filterChoice(this.state.myChoice))
                  .filter(this.filterChargertype(this.state.ChargerChoice))
                  .sort(this.sortPlacenames)
                  .map((s, key) => (
                      <option key={key} value={s.placename}>
                        {s.placename}
                      </option>
                  ))}
            </select>
            {this.state.myChoice1 && (
                <blockquote>
                  Selected Place Name: <b>{this.state.myChoice1}</b>
                </blockquote>
            )}
          </form>
          <hr />
          {this.state.showMap && (
              <div style={{ height: "400px", width: "100%" }}>
                <LoadScript googleMapsApiKey={this.state.mapApiKey}>
                  <GoogleMap
                      mapContainerStyle={{ height: "100%", width: "100%" }}
                      center={this.state.mapCenter}
                      zoom={14}
                  >
                    {/* DirectionsRenderer to display the directions on the map */}
                    {this.state.directions && (
                        <DirectionsRenderer directions={this.state.directions} />
                    )}
                  </GoogleMap>
                </LoadScript>
              </div>
          )}


          {/* Render the button to open Google Maps */}
          {this.state.showMap && (
              <div style={{ textAlign: "center", marginTop: "20px" }}>
                <button onClick={this.openGoogleMaps}>
                  Open in Google Maps
                </button>
              </div>
          )}

          {this.state.globalArray
              .filter(this.filterChargertype(this.state.ChargerChoice))
              .filter(this.filterChoice(this.state.myChoice))
              .filter(this.filterPlacename(this.state.myChoice1))
              .map((s, i) => (
                  <div key={i}>
                    <h3>Available Chargers For Your Destination</h3>
                    {/* nested map function to print the available charger types */}
                    {s.charger.map((s1, key) => (
                        <div>
                          {key + 1}: {s1}
                        </div>
                    ))}<h3>Latitude / Longitude:</h3>
                    {s.latitude}&#176;N &nbsp; {s.longitude}&#176;W
                    {/* user must manually click the button to calculate the distance */}
                    <div style={{ textAlign: "center" }}>
                      <button onClick={this.calculate}>
                        <b>Show Location</b>
                      </button>
                    </div>
                  </div>
              ))}
        </div>

    );
  }
}
export default App;
